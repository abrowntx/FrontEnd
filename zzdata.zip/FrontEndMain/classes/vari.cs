﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrontEndMain
{
    class vari
    {
        public static string DefaultDirectory;
        public static int CustID;
        public static double p1;
        public static double p2;
        public static double p3;
        public static double p4;
        public static string pn;
    }
}
