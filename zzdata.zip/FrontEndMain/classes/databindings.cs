﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrontEndMain
{
    class databindings
    {
        public class q1
        { public string lq1 { get; set; } }
        public class q2
        { public string lq2 { get; set; } }
        public class q3
        { public string lq3 { get; set; } }
        public class q4
        { public string lq4 { get; set; } }
        public class Multi
        { public string lMulti { get; set; } }
        public class PN
        { public string lPN { get; set; } }
    }
}
